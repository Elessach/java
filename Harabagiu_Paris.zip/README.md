# Projet Java - Léa & Louise

pour lancer depuis le terminal :
  $ java -jar Captcha.jar
