package fr.upem.captcha.images.ponts;

import fr.upem.captcha.images.Type;

public class Ponts extends Type{
}
