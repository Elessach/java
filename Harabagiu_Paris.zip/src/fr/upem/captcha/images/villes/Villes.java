package fr.upem.captcha.images.villes;

import fr.upem.captcha.images.Type;

public class Villes extends Type{
}