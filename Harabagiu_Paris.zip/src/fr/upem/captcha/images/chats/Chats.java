package fr.upem.captcha.images.chats;
import fr.upem.captcha.images.Type;

public class Chats extends Type{

}
