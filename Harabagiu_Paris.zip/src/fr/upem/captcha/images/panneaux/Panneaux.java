package fr.upem.captcha.images.panneaux;

import fr.upem.captcha.images.Type;

public class Panneaux extends Type{
}
