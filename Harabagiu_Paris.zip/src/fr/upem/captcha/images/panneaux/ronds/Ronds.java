package fr.upem.captcha.images.panneaux.ronds;

import fr.upem.captcha.images.panneaux.Panneaux;

public class Ronds extends Panneaux{

}
